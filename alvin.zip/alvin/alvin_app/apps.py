from django.apps import AppConfig


class AlvinAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'alvin_app'
