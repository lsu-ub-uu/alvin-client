function searchFunction() {
  var x = document.getElementById("divSearch");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}